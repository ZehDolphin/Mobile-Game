package com.heat.engine.math;

import java.util.ArrayList;

/**
 * A mathmatical polygon, used mostly for light calculations. <br>
 * 
 * @author Pontus Wirsching
 * @since 2016-04-09
 *
 */
public class Polygon extends Point {

	/**
	 * Points for each vertex, these are relative to the position variable. <br>
	 */
	public ArrayList<Point> points = new ArrayList<>();

	public Polygon(float x, float y) {
		super(x, y);
	}

	public Polygon(float x, float y, float[] xs, float[] ys) {
		super(x, y);

		int min = xs.length;
		if (ys.length < min)
			min = ys.length;
		for (int i = 0; i < min; i++) {
			addPoint(xs[i], ys[i]);
		}
	}

	public Point getPoint(int index) {
		if (index >= points.size()) {
			index -= points.size();
		}
		try {
			return points.get(index);
		} catch (Exception e) {

		}
		return null;
	}

	public void addPoint(Point p) {
		points.add(p);
	}

	public void addPoint(float x, float y) {
		points.add(new Point(x, y));
	}

	public Polygon[] triangulate() {
		Polygon[] result = new Polygon[points.size() / 2];

		int total = 0;
		for (int r = 0; r < result.length; r++) {
			Polygon p = new Polygon(x, y);
			for (int i = 0; i < 3; i++) {
				System.out.println(r + ", " + (i + total));
				p.addPoint(getPoint(i + total).x, getPoint(i + total).y);
			}
			total += 2;
			result[r] = p;
		}

		return result;
	}

}
