package com.heat.engine.graphics.windowEvents;

public interface OnWindowClose {

	public void onClose();
	
}
