package com.heat.engine.graphics.windowEvents;

public interface ResizeListener {

	public void resize(float width, float height);
	
}
