package com.heat.engine.graphics;

public interface Drawable {

	public void draw();
	
}
